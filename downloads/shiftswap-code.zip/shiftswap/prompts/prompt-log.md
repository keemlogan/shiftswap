# ShiftSwap — Prompt log

## Iteration 1 — ambiguities found while building

Each bullet: what was unclear → what the implementation does → suggested wording for the next prompt version.

- **`node --test tests/` fails on Node 24** (a directory argument is treated as a module path, error `Cannot find module …/tests`) → the script is `"test": "node --test tests/*.test.js"` → "script `"test": "node --test tests/*.test.js"`".
- **Read queries are not in the service list** (the UI needs week shifts, request lists, the approval comparison, payroll rows, …) → `services.js` also exports read-only queries (`getWorkplace`, `getSettings`, `getWorker`, `listWorkers`, `getFixedSchedules`, `getAvailability`, `getWeekShifts`, `listRequestableShifts`, `listMyRequests`, `listOwnerRequests`, `getApprovalPreview`, `listAttendance`, `getPayroll`, `unreadCount`, `defaultDeadline`) plus a `ServiceError` class carrying an error `code` → "services.js also exports read-only query functions for the screens (not wrapped in `tx`) and a `ServiceError(code, message, params)` that the UI translates by code."
- **Perfect attendance in a week that has not finished** (BR-06 says every own shift "was WORKED") → only an `ABSENT` shift (or a given-away shift under policy `ABSENT`) breaks attendance; a still-`SCHEDULED` shift does not. Without this, the approval panel could never show Minho as "eligible" before the week ends, contradicting the worked example → "In BR-06, a shift that is still SCHEDULED does not break perfect attendance; only ABSENT does (the weekly result is a projection until the week is over)."
- **Which workers get a WeeklySummary, and which weeks count for holiday pay** → `recomputeWeek` covers each worker with at least one shift (as current or original worker) in the week; payroll holiday pay sums only those weeks, so weeks that were never generated pay nothing → "A WeeklySummary exists only for workers who have a shift in that week."
- **No WeeklySummary rows in the seed** (§10 does not list them) → none are seeded; they are computed when the owner opens the weekly summary, approves a swap, confirms attendance or generates payroll → "The seed contains no WeeklySummary/Payroll rows; they are derived."
- **Base hours for shifts without confirmed attendance** (BR-11) → `WORKED` shifts use the recorded clock-in/out; `SCHEDULED` shifts in the month use scheduled hours and set `estimated = 1`; `ABSENT` shifts count 0 → state this explicitly in BR-11.
- **Premium pay at month level** (BR-08 mixes daily, weekly and night rules) → computed over the month's worked intervals: daily excess over 8 h per work date, weekly excess over 40 h of the remaining regular hours per ISO week (only the part of the week inside the month), plus night minutes 22:00–06:00; premium pay = premium hours × wage × 0.5, rounded down → "Weekly overtime in a payroll month uses only the days of that week inside the month."
- **The date used for BR-10 in a monthly payroll** → the first day of the month, or the contract start if later → "Evaluate BR-10 on the first day of the payroll month (or the contract start if later)."
- **"Effective hourly wage" in BR-07** → the worker's own `hourlyWage` (BR-09 says payroll computes with the worker's wage) → "effective hourly wage = Worker.hourlyWage."
- **Holiday pay rounding** → rounded down per week, then summed (TC-113) → "Round holiday pay down per week, then sum."
- **Attendance time format** (`clockIn`/`clockOut` are TEXT) → stored as `HH:MM` on the shift's date, end ≤ start meaning next day, like shift times → "Attendance.clockIn/clockOut are HH:MM on the shift date."
- **Who is notified on cancel and on expiry** → cancel: every target that was PENDING or ACCEPTED gets `REQUEST_CANCELLED`; expiry: requester and owner get `REQUEST_EXPIRED`, pending targets are closed without a message; acceptance: the other pending targets get `TARGET_CLOSED`; a decline notifies no one → list the recipients of each Notification.kind in §8.
- **Seed request `createdAt` and notification times** are not given → `2026-09-28T08:30` (before the demo clock) → give the value in §10.
- **Worker phone numbers** are not in §10 but NFR-11 needs them → fictional numbers `010-3827-1150`, `010-4172-2083`, `010-5290-3316`, `010-6631-4427`, `010-7748-5539` for ids 1–5 → list them in §10.
- **Names in the database** (§10 gives English and Korean names, the schema has one `name`) → English names stored (`Park Jiyoung`, `Dalbit Café`, …); the Korean UI shows them unchanged → "Store the English names; the Korean UI does not translate names."
- **Deleting a shift that already has a request or attendance** (FR-05) → refused with an explanatory message; the owner changes time or worker instead → state it in FR-05.
- **Deleting a fixed schedule row that already generated shifts** → the row is removed and those shifts keep existing with `fixedScheduleId = NULL` → state it in FR-02.
- **Demo clock persistence** → stored in `localStorage` under `shiftswap.clock.v1`; "Reset demo data" also resets the clock to `2026-09-28T09:00`; the language choice is stored under `shiftswap.lang` → name these keys in section 1.
- **Shared UI helpers** (escaping, number/date formatting, form error box, week navigation, row editor) have no module in the layout → formatting and the form error box live in `ui/i18n.js`, week navigation in `ui/schedule.js`, the weekday/start/end row editor in `ui/availability.js` (reused by `workers.js`) → "Shared UI helpers may live in `i18n.js`."
- **Stripe pattern vs "no gradients"** → the 45° amber stripe of the handed-over shift uses `repeating-linear-gradient`, the only gradient in the stylesheet → "the stripe may use `repeating-linear-gradient`; no other gradients."
- **Tables at 360 px** (NFR-02, no horizontal scroll) → below 720 px each table row turns into a stacked card with the column name before each value → state the pattern in section 3.

## Iteration 2 — changes from v1 to v2 and result

v2 of the prompt (`prompts/prompt-v2.md`; v1 kept as `prompts/prompt-v1.md`) and the matching spec edits fold in the 21 build ambiguities of iteration 1 and the gaps found in the document review. The app was then brought to v2.

| # | Source | Change in prompt / spec | Change in code | Verification |
|---|---|---|---|---|
| 1 | Build ambiguity | Prompt §1: test script `node --test tests/*.test.js` | none (already so) | `npm test` runs |
| 2 | Build ambiguity | Prompt §1: services.js also exports read-only queries and `ServiceError(code, message, params)` | none (already so) | all service tests |
| 3 | Build ambiguity | BR-06: a still-SCHEDULED shift does not break perfect attendance (projection until the week ends) | none (already so) | TC-085, TC-063 |
| 4 | Build ambiguity | §8 note: WeeklySummary only for workers with a shift that week; seed has no WeeklySummary/Payroll rows | none (already so) | TC-001, TC-088 |
| 5 | Build ambiguity + document review (BR-11 "estimated" semantics) | BR-11: WORKED → recorded hours, SCHEDULED → scheduled hours + `estimated = 1`, ABSENT → 0 | none (already so) | TC-114, TC-112 |
| 6 | Build ambiguity | BR-08: monthly weekly overtime uses only the days of the ISO week inside the month; premium pay rounded down | none (already so) | TC-092–TC-094, TC-095 |
| 7 | Build ambiguity | BR-10: evaluated on the first day of the month, or contractStart if later | none (already so) | TC-102, TC-104 |
| 8 | Build ambiguity | BR-07: pay uses `Worker.hourlyWage`, rounded down per week, then summed | none (already so) | TC-111, TC-113 |
| 9 | Build ambiguity | §8 note: Attendance clockIn/clockOut are `HH:MM` on the shift date | none (already so) | TC-071 |
| 10 | Build ambiguity + document review (UC-12 cancel recipients) | §8 recipients table; FR-19 (cancel notifies every PENDING or ACCEPTED target); a decline notifies no one | none needed (implementation already matched); recipients now asserted explicitly | TC-133 (new), TC-052, TC-121, TC-123 |
| 11 | Build ambiguity + document review (seed request createdAt) | §10: seed request `createdAt 2026-09-28T08:30`; fictional phone numbers; English names in DB | none (already so) | TC-001, TC-131 |
| 12 | Build ambiguity | FR-05: deleting a shift with a request or attendance is refused | none (already so) | TC-01A (new) |
| 13 | Build ambiguity | FR-02: deleting a fixed-schedule row keeps its shifts (`fixedScheduleId = NULL`) | none (already so) | TC-01B (new) |
| 14 | Build ambiguity | Prompt §1: keys `shiftswap.clock.v1`, `shiftswap.lang`; Reset also resets the clock | none (already so) | headless check (reset, reload) |
| 15 | Build ambiguity | Prompt §1: shared UI helpers (escaping, formatting, form error box) in `i18n.js` | none (already so) | review |
| 16 | Build ambiguity | Prompt §3: stripe may use `repeating-linear-gradient`, no other gradient; tables become stacked cards below 720 px | none (already so) | headless check: 360 px, no overflow on any screen |
| 17 | Document review | Schema: `Payroll.minWageAck INTEGER NOT NULL DEFAULT 0`; BR-09: acknowledgement sets it; prompt: `acknowledgeMinWage` service, Acknowledge button on the warning row, Confirm disabled until every warning row is acknowledged, "Estimated" chip | `db.js` schema column; new `acknowledgeMinWage(yearMonth, workerId)`; `confirmPayroll(yearMonth)` now checks the persisted `minWageAck` (the v1 `acknowledgeWarnings` option was removed); payroll screen: per-row Acknowledge button → "Acknowledged" chip, Confirm disabled with a hint until all are acknowledged | TC-104, TC-105 (new), TC-115; headless: Confirm disabled → Acknowledge → enabled → survives reload → confirmed |
| 18 | Follows from #17 (schema change) | Schema change vs. saved browser copies | `openDatabase` checks `PRAGMA table_info(Payroll)` for `minWageAck`; an older saved copy is replaced by the seed (key stays `shiftswap.db.v1`, a console warning explains it) | TC-002 (new) |
| 19 | Document review | §10: demo walkthrough S7 (ABSENT policy, Minho's Sat 10-03 12:00–18:00; Seoyeon and Hana eligible, Doyun excluded by overlap; Minho loses eligibility after approval); done criterion 2 requires a test | none needed in the app; new test | TC-08B (new) |
| 20 | Document review (§14 calendar) | NFR-07 date corrected to 2026-12-04; §14 course calendar | none (not app behaviour) | — |

Decisions made while building v2:

- **Regenerating a draft resets the acknowledgement.** "Re-generating a month replaces DRAFT rows only", so the new row starts with `minWageAck = 0` and must be acknowledged again (TC-105). This rule has since been added to BR-09.
- **Old saved databases are replaced, not migrated.** Replacing keeps the schema exactly as spec §8 (an `ALTER TABLE` would append the column at the end); the cost is that demo edits made before v2 are lost, which is acceptable for demo data.

Result: `npm test` 58 tests, 58 pass, 0 fail (52 in v1, plus TC-002, TC-01A, TC-01B, TC-105, TC-08B, TC-133). Headless Chrome: 70/70 checks pass, 0 console errors. The checks cover: sign-in; the done-criterion 4 walkthrough; the payroll acknowledgement flow including reload; and every screen for both roles in English and Korean at 1440 px and 360 px with no horizontal scroll.

## Iteration 3 — changes from v2 to v3 and result

Source for every row: UI review of the running v2 app (text too small, content in a narrow centred column with large empty areas, weekly board read as a list of cards rather than a schedule). All prompt changes are in §2/§3 and spec.md is unchanged; the only service-layer change is row 9 (from the traceability check), which added tests.

| # | Source | Change in prompt | Change in code | Verification |
|---|---|---|---|---|
| 1 | UI review | Sign-in rows show name, role and a one-line summary (owner: "Owner · Dalbit Café · 4 workers"; worker: fixed shifts + weekly contract hours) | `ui/login.js`: summary built from `getFixedSchedules` and `contractHours`, days with the same time range grouped ("Tue, Thu 18:00–23:00, Sat 12:00–18:00 · 16 h/week") | headless: all five summaries read back as expected |
| 2 | UI review | Every page starts with the title and one sentence on what the page is for | `pageHead(title, purpose, actions)` helper in `ui/i18n.js`, used by all 11 screens; `purpose.*` sentences in English and Korean (attendance has one per role) | headless: every route for both roles has `.page-head .purpose` |
| 3 | UI review | Owner overview strip above the board: approvals waiting, open substitute requests, this week's shifts · hours, each linking to its page | `ui/schedule.js` `overviewStrip()`; counts from `listOwnerRequests`, hours from `getWeekShifts` of the demo-clock week; links to Approvals / Weekly summary | headless: three figures ("This week 9 shifts · 50 h" in the seed) |
| 4 | UI review | Weekly board as a time grid: hour axis from the earliest start to the latest end (whole hours), 44 px/hour, hourly lines, hour labels in a left gutter, today's header marked, blocks positioned and sized by time; handover/pending markers unchanged | `ui/schedule.js` rewritten around `board()` + `layoutDay()`: blocks get `--top/--height` from their minutes; overlapping shifts of one day share the width in lanes; overnight ends extend past 24:00; today's header gets a "Today" chip and underline | headless geometry: Sat 10:00–16:00 = 264 px (6 h) at the axis start, Sat 12:00–18:00 starts 88 px lower and sits beside it, Mon 18:00–23:00 at 8 h, axis 10:00–23:00, today = Mon 09-28 |
| 5 | UI review | Empty states say what will appear and offer the next action as a button | `emptyState(text, action)` helper; board (owner: "Generate week of …"; worker: availability or "Go to this week"), payroll ("No payroll for September 2026 yet." + "Generate draft for September 2026"), approvals (+ "See open requests"), inbox, my requests, attendance, weekly summary | manual review of each screen; unused v2 empty-text keys removed |
| 6 | UI review | Type scale: base 15 px / 1.6; page title 28 px / 800 / −0.02em; section 18 px / 700; small 13 px (min 12 px); inputs 16 px on mobile | `styles.css` heading and body rules; inputs 16 px below 900 px; no font size below 12 px | headless: h1 computes to 28 px / 800 |
| 7 | UI review | Layout: nav 220 px; content starts right after the nav, 32 px padding, max-width 1200 px, left-aligned; gaps between groups at least twice the gaps inside a group | nav column 220 px; content no longer centred; `#view` is a flex column with 32 px between groups, 8–12 px inside (`.group`) | headless: nav width 220 px, content left edge 220 px |
| 8 | UI review (kept) | < 900 px day-by-day list; < 720 px stacked-card tables | below 900 px the grid drops its gutter and hour lines and blocks become static cards in day order; the table rule is unchanged | headless: every screen for both roles, EN/KO, 1440 and 360 px, no horizontal scroll; at 360 px blocks are `position: static` |
| 9 | Traceability check (FR-01, FR-20 / NFR-11 had no automated test) | none yet. Suggested for §1: "services.js exports `menuFor(role)`, the screens a role may open (FR-20); the router uses it for the menu and the role guard." | The role-to-menu table moved from `main.js` into a pure exported `menuFor(role)` in `services.js` (returns a copy); `main.js` uses it for the navigation and the redirect of other routes. NFR-11 visibility was already decided in the service layer (`listWorkers(viewer)`, `listAttendance(week, viewer)`), so no new helper was needed for it. | TC-01C, TC-01D (FR-01 register/edit and every validation error), TC-134 (FR-20 menus), TC-135 (NFR-11 attendance rows and phone/wage) |

Found and fixed during verification: the 32 px group gap was first set on `.content`, but the screens render inside `#view`, so the header, overview strip and week navigation touched; the gap now sits on `#view`.

Found while capturing the report screenshots (docs/img) and fixed:
- the "Substitute requested" chip was clipped inside a narrow shift block (chips inside blocks now wrap);
- the reply-deadline date-time field was too narrow for its value (form columns now have a 240 px minimum);
- the Korean "수정" button broke onto two lines in the narrow overlapping Saturday blocks (block buttons no longer wrap);
- on phones the week navigation wrapped awkwardly (the week label now takes its own line above the buttons).

Result: `npm test` 62 tests, 62 pass, 0 fail (58 + TC-01C, TC-01D, TC-134, TC-135 from row 9). Headless Chrome: 82/82 checks pass, 0 console errors. Screenshots of the owner board: `/tmp/shiftswap-owner-board-1440.png`, `/tmp/shiftswap-owner-board-360.png`.

## Iteration 5 — independent code review and reproduction run 1

Source of every row: independent code review / reproduction run 1 (a reviewer script reproduced each defect against the v3 code). Spec clarifications: FR-04, FR-05, FR-13, BR-02, BR-10, BR-12, §8 WeeklySummary note.

| # | Source | Change | Code | Test IDs |
|---|---|---|---|---|
| 1 | Independent code review / reproduction run 1 (BR-02) | The acceptor must still have no overlapping shift on the date, re-checked at acceptance and again at approval (ACCEPTOR_BUSY) | `services.js`: `acceptorClash()` + `acceptorBusyError()`; `respondToRequest` (accept) and `decideRequest` (approve) throw ACCEPTOR_BUSY inside the transaction, so nothing changes | TC-054, TC-055 |
| 2 | Independent code review / reproduction run 1 (spec §7, FR-13) | Confirm and mark-absent require a SCHEDULED shift; WORKED/ABSENT are final (ATTENDANCE_CLOSED) | `services.js`: status guard in `confirmAttendance` and `markAbsent`; TC-089 now marks a SCHEDULED shift of the current week absent instead of an already WORKED one | TC-072, TC-073, TC-089 (changed) |
| 3 | Independent code review / reproduction run 1 (FR-04) | A fixed slot is skipped when that fixed schedule already produced a shift anywhere in the week, or when the worker already has an overlapping shift that day | `services.js` `generateWeek`: week-range lookup by `fixedScheduleId` plus an overlap check on the worker's shifts of the date | TC-01E, TC-01F |
| 4 | Independent code review / reproduction run 1 (§8 WeeklySummary) | Recomputing a week deletes the rows of workers who no longer have a shift (current or original) that week, so payroll never counts stale holiday pay | `services.js` `recomputeWeek`: whole-week run deletes rows of other workers; a listed worker without shifts has the row deleted instead of upserted | TC-08C |
| 5 | Independent code review / reproduction run 1 (FR-05) | Worker, date or time of a shift with an open (REQUESTED/ACCEPTED) request cannot change (SHIFT_OPEN_REQUEST) | `services.js` `editShift`: guard before validation; `ui/i18n.js` error dictionary: `err.SHIFT_OPEN_REQUEST` (ko, en) | TC-01G |
| 6 | Independent code review / reproduction run 1 (BR-12) | Accept/decline and approve/reject expire an overdue request themselves (deadline ≤ now or shift start ≤ now) and refuse with REQUEST_CLOSED | `services.js`: `isOverdue()`, `expireRequest()` shared with `expireOverdue`; the expiry is committed and REQUEST_CLOSED is thrown after the transaction (`throwIfExpired`) so the throw does not roll it back | TC-124, TC-125 |
| 7 | Independent code review / reproduction run 1 (BR-10, BR-09) | Probation window contractStart (inclusive) to +3 months (exclusive), only with probationEnd; the 90 % floor must be exact | `rules.js` `probationApplies` already matched (boundary test added); `computePayrollRow` uses `minimumHourly * 9 / 10` because `10320 * 0.9` is not exactly 9,288 in floating point | TC-106, TC-107 |
| 8 | Follows from #1 | New error code shown in the UI | `ui/i18n.js` error dictionary: `err.ACCEPTOR_BUSY` (ko, en); REQUEST_CLOSED and ATTENDANCE_CLOSED already translated | — |
| 9 | Product-owner review (prompt §2.0 item 7) | Korean display names: in the Korean UI the seed people and store are shown by their spec §10 names (박지영, 이서연, 최민호, 정하나, 강도윤, 달빛카페) and addressed as full name + 님 ("최민호님"); stored names stay English, names not in the map are shown as stored; the English UI is unchanged | `ui/i18n.js`: `KO_NAMES` display map with `displayName()`, `honorific()`, `initial()`, and `given()` returning the Korean full name in ko; every screen and `main.js` render names through them | `tools/check.mjs` DC-3/DC-4 (Korean names on sign-in, "이서연님이 대타를 구해요", "최민호님이 먼저 수락했어요", handover marker 최민호 / 이서연) |

Result: `npm test` 77 tests, 77 pass, 0 fail.

## Iteration 4 — changes from v3 to v4 and result

Source for every row: the UX redesign review requested by the product owner ("the UI is too thin; redesign it the way a consumer-app product team would: intuitive, user-centred, obvious which button to press"). The prompt's §2 and §3 were rewritten; the spec gained NFR-13 and the new FR-20 wording. Business rules, schema and the existing services did not change: the only service additions are read-only queries.

| # | Change in prompt / spec | Change in code | Verification |
|---|---|---|---|
| 1 | §2.0 rule 1 and done criterion 5: one filled primary button per screen, fixed to the bottom below 900 px | Every screen puts its page-level action in `pageHead({ cta })`; `.cta-bar` is fixed above the tab bar below 900 px and inline on desktop. On Home the most urgent item's own button is the primary, and every other action is secondary (grey) or text | `tools/check.mjs` DC-5: 26 scenes × 2 languages × 1280 / 390 px, each with exactly 1 visible `.btn-primary` |
| 2 | §2.0 rule 8: a disabled button always explains why | `button({ disabled, reason })` renders the reason beneath the button and links it with `aria-describedby` | DC-5: every disabled button has a visible reason |
| 3 | §3 touch targets ≥ 44 × 44 px | Buttons 52 px (mobile) / 44 px (desktop); chips, weekday chips, icon buttons and the brand link are at least 44 px | DC-5 touch-target audit (radios, checkboxes and switches inside a label are measured by their label row) |
| 4 | §2.1 navigation: Home / Schedule / Swaps / Me and Home / Schedule / Staff / Pay; bell, demo-clock chip → Demo tools, account switcher; Settings in the header menu | `menuFor(role)` returns the four tabs; new `routesFor(role)` adds the header screens (notifications; settings for the owner) for the role guard. Left navigation with line icons ≥ 900 px, 64 px tab bar below; Demo tools as a popover (desktop) / sheet (mobile) with the clock and the reset confirmation inside the panel | TC-134 (updated); DC-3, DC-4 |
| 5 | §2.2 sign-in = 3-step demo tour + all accounts with one-line summaries | `login.js`: numbered tour card; step 1 is remembered in this browser (`shiftswap.tour.v1`), steps 2–3 follow the state of the seed request; the next step is the primary button; "Start over" once all three are done | DC-4: the tour drives the walkthrough and marks all 3 steps done |
| 6 | §2.3 Worker Home; spec: `getWorkerHome(workerId)` | New service `getWorkerHome`: incoming requests with the effect of accepting, "someone else was faster", my open requests, next shift, this week's hours and holiday allowance, shifts to record. New `home.js` renders it | TC-064 (Minho 16 → 21 h, ₩33,024 unchanged; Doyun sees Minho was faster; Seoyeon's tracker); DC-4 |
| 7 | §2.5 Owner Home; spec: `getOwnerHome()` | New service `getOwnerHome`: decision cards with the effect for both people (holiday pay before → after), open requests, attendance to confirm, unacknowledged pay warnings, today, this week; `taskCount`. `approvals.js` renders the decision card with a compact before/after comparison behind "Details" | TC-065; DC-4 (decision card shows 16 → 21 h and "33,024원 유지", Approve works) |
| 8 | §2.0 rule 3: show the consequence before committing | The shared `swapEffect()` in services (also behind `getApprovalPreview`) adds `holidayPay` before and after; `effectLines()` turns it into the sentences on the accept and approve cards; a change in eligibility is highlighted in amber | TC-064, TC-065 |
| 9 | §2.4 three-step request flow with step indicator, reason/deadline chips, review with recipients, result screen | `requests.js`: `#/swaps/new/1…3/done`, draft kept in `sessionStorage`, back / close, tab bar hidden; deadline chips that cannot be used are disabled with the reason; new service `previewCandidates(shiftId, requesterId)` lists the recipients (BR-01) before sending | TC-066; scenes flow-1/2/3/done in DC-5 |
| 10 | §2.0 rule 6: request status as the tracker 요청 → 수락 → 승인, end states labelled | `tracker(status)` in `components.js`, used on Home, Swaps, the result screen and history | DC-4 (Seoyeon's tracker) |
| 11 | §2.6 schedule: time grid ≥ 900 px, day list < 900 px, detail sheet with history and viewer-specific actions | `schedule.js`: shift blocks are buttons opening a side panel / bottom sheet; new service `getShiftDetail(shiftId)` gives the history and whether the shift can be deleted (FR-05, refused with its reason); owner primary "근무 추가" or "이번 주 근무표 만들기"; worker primary "대타 구하기" | DC-4 handover marker; scene schedule-detail |
| 12 | §2.7 Pay with Weekly / Monthly segments; acknowledgement; confirm disabled with its reason | `payroll.js` (route) + `weekly.js` (cards); monthly table becomes cards below 720 px; "확인했어요" per warning; "9월 급여 확정하기" disabled with "최저임금 경고 1건을 확인해야 확정할 수 있어요" | scenes pay-week, pay-month, pay-month-empty |
| 13 | §2.8 Staff (weekday-chip fixed-schedule editor with the resulting weekly hours), Me (availability, attendance, own phone/wage only), Settings (radio cards) | `workers.js`, `availability.js` (shared weekday-chip editor), `settings.js` | TC-135 (NFR-11); scenes staff-detail, me, settings |
| 14 | §2.0 rule 7: Korean 해요체 by default, complete English, human dates ("9월 30일(수) 18:00–23:00", "내일 21:00까지", D-2), no IDs in the UI | `i18n.js` rewritten: `ko` is the default, full `en` table, `fmtDate` / `fmtWhen` / `dday` / `fmtClock` / `fmtYMD`; English plurals handled where a count can be 1 | review screenshots in both languages |
| 15 | §3 visual tokens (Pretendard only, 16 px body, borderless 16 px-radius cards on #F2F4F6, 52 px buttons, inline SVG icons, 180 ms motion) | `styles.css` rewritten; JetBrains Mono removed; icons in `components.js`; sheets/steps animate 180 ms and not under `prefers-reduced-motion` | review screenshots; DC-5 no horizontal scroll at 390 px |
| 16 | Harness moved into the repository | `tools/lib.mjs` (static server + DevTools client, Chrome forced to an en-US system locale so native date inputs read the same everywhere), `tools/scenes.mjs` (26 named states), `tools/check.mjs` (DC-3/4/5), `tools/screens.mjs` (review and report screenshots), `tools/nfr03.mjs` | `node tools/check.mjs`: 115/115; `node tools/nfr03.mjs` (see docs/nfr03-measurement.md) |

Ambiguities found while building v4 (what was unclear → what the implementation does → suggested wording):

- **No module for Home, and no place for shared components** in the §1 module list → added `app/ui/home.js` (both Homes) and `app/ui/components.js` (icons, buttons, page header with its primary action, tracker, sheets, toasts) → add both files to the §1 list.
- **Screens reached from the header** (notifications; settings for the owner) are not tabs, but the router must allow them → `routesFor(role)` = tabs + header screens; `menuFor(role)` stays the tabs → "`routesFor(role)` returns every route a role may open (its tabs plus the header screens)".
- **§1 puts "Reset demo data" in the header menu, §2.1 in Demo tools** → it lives in Demo tools, with the confirmation in the panel (§2.0 says §2 wins) → change §1 to "in Demo tools".
- **The example copy uses Korean given names ("서연님"), but spec §10 stores English names** → the Korean UI uses the given name from the stored name with 님 ("Seoyeon님"); lists show the full stored name → either store Korean display names in the seed or state that the given name is used as stored.
- **Home can list several actionable items; each has "its own action button"** → the first (most urgent) item's button is the screen's primary; the others are secondary. On Swaps the primary is "대타 구하기" (§2.4), so the accept buttons there are secondary → state this in rule 1.
- **Primary action on the sticky bar vs. on a card** → page-level actions (Swaps, flow steps, Schedule, Pay, Staff, Me, Settings, Notifications) go in the sticky bar; on Home the primary stays on its card, and a sticky "근무표 보기" appears only when nothing needs the person → state it.
- **Screens with no natural single action** → Notifications: "모두 읽음으로 표시" (disabled with "새 알림이 없어요" when there are none); Pay → Weekly: "9월 급여 보기"; Demo tools: "이 시각으로 맞추기" (the clock changes on the button, not on every input change); a confirmed month: "9월 급여 확정 완료", disabled with its reason → list these in §2.
- **"Day-by-day list with today first expanded"** → days stay in calendar order; today is expanded and the other days are collapsed with their shift count (for another week, the first day with shifts is expanded) → "days in order, today expanded, others collapsed".
- **Where step 1 of the tour counts as done** → when its button is used (remembered in `localStorage` `shiftswap.tour.v1`, cleared by the demo reset); steps 2 and 3 are read from the seed request's state → state it.
- **Reason chips** → the chosen chip is stored as its label in the current language ("시험" / "Exam"); "직접 입력" stores the typed text → state it.
- **Staff save touches two services** → `registerWorker` then `saveFixedSchedule` (two transactions); if the schedule is invalid after a new worker was created, the screen continues on that worker's page, so a second save cannot create a duplicate → acceptable; or add a combined service if one transaction is required.

Found and fixed while reviewing the screenshots (both languages, 1280 and 390 px):
- The flow at desktop width was squeezed into the 220 px navigation column (the flow hides the nav, but the grid kept it).
- A toast from the previous person stayed visible after switching accounts.
- The FR-11 details table stacked into four tall cards on phones. It is now a compact now / after comparison per person.
- The header overflowed by 4 px in English at 390 px, and the brand link was 29 px tall.
- Weekday chips were 39 px wide at 390 px.
- Fieldset legends sat on the card edge.
- The payroll warning row painted each cell separately on phones.
- The shift history read "요청 · 요청".
- English copy errors: "1 things", "Seoyeon This week", "1 shifts", "warning(s)", "Please reply tomorrow".
- After the parallel code review (Iteration 5) made editing a shift with an open request an error (SHIFT_OPEN_REQUEST), the detail sheet now disables "시간 바꾸기" and "담당자 바꾸기" for such a shift and shows that reason beneath them, instead of failing after the tap (§2.0 rule 8).
- Sheets opened with a focus ring on the first button (they now focus their title).

Result:
- `npm test`: 77 tests, 77 pass, 0 fail. That is v3's 62, plus TC-064, TC-065 and TC-066 for the new queries (TC-134 was updated), plus 12 tests added by another team member in parallel: TC-01E/F/G, 054, 055, 072, 073, 08C, 106, 107, 124 and 125.
- `node tools/check.mjs`: 115/115 pass with 0 console errors. That covers DC-3, the Korean walkthrough of DC-4 (10 checks), and DC-5 for 26 scenes × 2 languages × 2 widths.
- NFR-03 re-measured on v4: the slowest screen renders in 18 ms and paints in 43 ms.

## Iteration 6 — requirements change: availability removed, can't answer and FAILED

Source of every row: product-owner review of the running app (2026-09-27, spec §15). When no co-worker's availability matched, the owner only got a "no candidate" notice with nothing to do, and availability slots were extra data workers had to keep up to date. Spec changes: UC-02 and FR-03 retired, BR-01 without availability, new BR-13 and FR-22, FR-08 and FR-09 reworded, §7 SubRequest state FAILED, §8 table Availability removed (11 tables) and NO_CANDIDATE replaced by REQUEST_FAILED, §10 seed without availability (seed request targets Minho, Hana and Doyun) and walkthrough S8.

| # | Spec change | Code (`app/core`) | Tests |
|---|---|---|---|
| 1 | BR-01: eligible = active WORKER, not the requester, no overlapping shift that date; availability is not used | `rules.js` `isEligibleCandidate({ worker, requesterId, shift, workerShifts })` (no `availability` argument; a given `worker.role` must be WORKER); `services.js` `eligibleCandidates` / `previewCandidates` no longer read availability | TC-014, TC-015 (rewritten), TC-016, TC-066 (Sun 10-04 now has three recipients) |
| 2 | UC-02 / FR-03 retired; §8 table Availability removed | `db.js`: `Availability` dropped from `SCHEMA` and the seed; `services.js`: `getAvailability` and `saveAvailability` removed; `menuFor` / `routesFor` had no availability route (unchanged) | TC-001 (no Availability table), TC-08A, TC-122, TC-125 (setup no longer registers availability), TC-134 (unchanged) |
| 3 | §10 seed: request 1 targets Choi Minho, Jung Hana and Kang Doyun | `db.js` seed: three SubRequestTarget rows and three REQUEST_RECEIVED notifications | TC-001, TC-051, TC-052, TC-054, TC-065, TC-123 (three targets) |
| 4 | §7 / §8: SubRequest.status FAILED (final) | `db.js`: FAILED in the CHECK list; `hasCurrentSchema()` also requires FAILED, so a saved copy from iteration 5 is replaced by the seed | TC-003 |
| 5 | BR-13 / FR-08: no eligible candidate at creation → FAILED at once, REQUEST_FAILED to requester and owner | `rules.js` `hasNoTaker(responses)`; `services.js` `failRequest()`; `createSubRequest` returns `{ id, status, candidates }` with status `'FAILED'` when there is no candidate | TC-025 (rewritten), TC-13B, TC-13F |
| 6 | BR-13 / FR-22: the can't (DECLINED) that leaves every target DECLINED → FAILED; a single can't notifies no one | `respondToRequest(requestId, workerId, 'DECLINED')` re-reads the targets in the same transaction and calls `failRequest()`; it returns `{ status: 'REQUESTED' \| 'FAILED' }` | TC-13A, TC-13C, TC-133 (REQUEST_FAILED to [owner, requester] instead of NO_CANDIDATE; TARGET_CLOSED now reaches Hana) |
| 7 | BR-13: accepting or cancelling a FAILED request is refused | unchanged guards now cover FAILED: REQUEST_CLOSED with `params.status = 'FAILED'`; `expireOverdue` ignores FAILED | TC-13A |
| 8 | FR-22 / prompt §2.3, §2.5: Home shows the failed request until acknowledged (확인했어요); it counts as an owner task | `getWorkerHome(workerId).failed` and `getOwnerHome().failed` (unread REQUEST_FAILED notifications); `taskCount` includes `failed`; `markNotificationsRead(workerId, ids?)` marks only the given ids (the old one-argument form still marks everything) | TC-13D |
| 9 | §10 walkthrough S8 | — | TC-13E |

Result: `npm test` 84 tests, 84 pass, 0 fail (the 77 tests of iteration 5, updated where they assumed availability, plus TC-13A–F and TC-003).
